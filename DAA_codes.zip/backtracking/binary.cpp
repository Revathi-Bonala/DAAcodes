#include<bits/stdc++.h>
using namespace std;
void print(int a[],int n)
{
    for(int i=0;i<n;i++)
    cout<<a[i]<<" ";
    cout<<"\n";
}
void binary(int bin[],int n,int k)
{
    if(k==n)
    {
        print(bin,n);
        return;
    }
    for(int i=0;i<2;i++)
    {
        bin[k]=i;
        binary(bin,n,k+1);
    }
}
int main()
{
    int n;
    cin>>n;
    int bin[n];
    bin[0]=0;
    binary(bin,n,0);

}