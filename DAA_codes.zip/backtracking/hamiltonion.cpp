void print(int a[],int n)
{
    for(int i=0;i<=n;i++)
    cout<<a[i]<<" ";
    cout<<"\n";
}
bool issafe(vector<vector<int>>adj,int i,int k,int a[],int n)
{
    if(k==n)
    {
    for(int j=0;j<k;j++)
    {
        if(a[j]==i||adj[i][a[k-1]]!=1 || adj[i][a[0]]!=1 )
        return false;

    }
    }
    else{
        for(int j=0;j<k;j++)
        {
            if(a[j]==i || adj[i][a[k-1]]!=1)
            return false;

        }
    }
    return true;
}
void hamiltonion(vector<vector<int>>& adj,int n,int k,int a[])
{
    if(k==n+1)
    {
        print(a,n);
        return n;
    }
    for(int i=0;i<=n;i++)
    {
        if(issafe(adj,i,k,a,n))
        {
            a[k]=i;
            hamiltonion(adj,n,k+1,a);
        }
    }
}
int main()
{
    int n,e;
    cin>>n>>e;
    vector<vector<int>>adj(n+1,vector<int>(n+1,0));
    for(int i=0;i<e;i++)
    {
        int u,v;
        cin>>u>>v;
        adj[u][v]=1;
        adj[v][u]=1;
    }
    int a[n+1];
    hamiltonion(adj,n,1,a);
}