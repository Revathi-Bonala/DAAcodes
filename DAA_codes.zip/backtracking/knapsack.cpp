#include<bits/stdc++.h>
using namespace std;
int print(int val[],int wt[],int n,int sum,int bin[])
{
    int s=0;
    for(int i=1;i<=n;i++)
   {
     if(bin[i]==1)
     {
     s+=val[i-1];
     sum-=wt[i-1];
     }
   }
   if(sum==0)
   return s;
    else
    return 0;
}
void knap(int val[],int wt[],int n,int sum,int k,int& maxi,int bin[])
{
    if(k==n+1)
    {
        int ans=print(val,wt,n,sum,bin);
        maxi=max(maxi,ans);
        return;
    }
    for(int i=0;i<2;i++)
    {
        bin[k]=i;
        knap(val,wt,n,sum,k+1,maxi,bin);
    }
}
int main()
{
    int n,sum;cin>>n>>sum;
    int wt[n],val[n];
    for(int i=0;i<n;i++) cin>>wt[i];
    for(int i=0;i<n;i++)    cin>>val[i];
    int bin[n+1]={0};
    bin[0]=0;
    int maxi=0;
    knap(val,wt,n,sum,1,maxi,bin);
    cout<<maxi<<endl;
    
    }