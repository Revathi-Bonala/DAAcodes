#include<bits/stdc++.h>
using namespace std;
void print(int a[],int n)
{
    for(int i=0;i<n;i++)
    cout<<a[i+1]<<" ";
    cout<<"\n";
}
bool issafe(int a[],int c,int r)
{
    for(int j=0;j<r;j++)
    {
        if(a[j]==c || abs(a[j]-c)==abs(r-j))
        return false;

    }
    return true;
}
void nqueen(int a[],int n,int k)
{
    if(k==n+1)
    {
        print(a,n);
        return;
    }
    for(int i=1;i<=n;i++)
    {
        if(issafe(a,i,k))
        {
            a[k]=i;
            nqueen(a,n,k+1);
        }
    }
}
int main()
{
    int n;
    cin>>n;
    int a[n+1];
    nqueen(a,n,1);
}
