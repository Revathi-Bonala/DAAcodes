#include<bits/stdc++.h>
using namespace std;
void print(int a[],int n)
{
    for(int i=0;i<n;i++)
    cout<<a[i]<<" ";
    cout<<"\n";
}
bool issafe(int a[],int i,int k)
{
    for(int j=0;j<k;j++)
    {
        if(a[j]==i) return false;
    }
    return true;
}
void permutation(int a[],int n,int k)
{
    if(k==n)
    {
        print(a,n);
        return;
    }
    for(int i=0;i<n;i++)
    {
        if(issafe(a,i,k))
        {
            a[k]=i;
            permutation(a,n,k+1);
        }
    }
}
int main()
{
    int n;
    cin>>n;
    int a[n];
    permutation(a,n,0);
}