#include<bits/stdc++.h>
using namespace std;
void print(int a[],int n,int sum,int wt[])
{
    int s=0;
    for(int i=0;i<n;i++)
    {
      if(a[i]==1) s+=wt[i];
    }
    if(s==sum)
    {
        for(int i=0;i<n;i++)
        {
            if(a[i]==1)
            cout<<wt[i]<<" ";
        }
        cout<<"\n";
    }
    return;
}
void subset(int a[],int n,int sum,int k,int wt[])
{
    if(k==n)
    {
        print(a,n,sum,wt);
        return;
    }
    for(int i=0;i<2;i++)
    {
        a[k]=i;
        subset(a,n,sum,k+1,wt);
    }
}
int main()
{
    int n;
    cin>>n;
    int sum;
    cin>>sum;
    int wt[n];
    for(int i=0;i<n;i++)
    cin>>wt[i];
    int a[n];
    subset(a,n,sum,0,wt);
}