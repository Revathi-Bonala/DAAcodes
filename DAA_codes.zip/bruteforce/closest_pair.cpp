#include<bits/stdc++.h>
using namespace std;
class point{
    public:
    int x,y;
};
void sort(point p[],int n)
{
    for(int i=0;i<n-1;i++)
    {
        for(int j=0;j<n-i-1;j++)
        {
            if(p[j].x>p[j+1].x)
            {
               point t=p[j];
               p[j]=p[j+1];
               p[j+1]=t;
            }
        }
    }
}
double bruteforce(point p[],int start,int end)
{
    double mini=INT_MAX;
    for(int i=start;i<end;i++)
    {
        for(int j=i+1;j<=end;j++)
        {
            double d=pow((p[j].y-p[i].y),2.0)+pow((p[j].x-p[i].x),2.0);//under root((y2-y1)^2 +(x2-x1)^2
             double dis=sqrt(d);
             mini=min(dis,mini);
        }
    }
    return mini;
}
double closestpoint(point p[],int start,int end)
{
    if(end-start<3)
    {
    return bruteforce(p,start,end);
    }
    double mid=(end+start)/2;
    double dl=closestpoint(p,start,mid);
    double dr=closestpoint(p,mid+1,end);
    double least=dl<=dr?dl:dr;
    point strip[100];
    int i=0;
    for(int k=start;k<=end;k++)
    {
        if(p[k].x<=p[k].x+least || p[k].x>=p[k].x-least)
        strip[i++]=p[k];
    }
    double db=bruteforce(strip,0,i-1);
    double m=least<=db?least:db;
    return m;
}
int main()
{
    int n;
    cin>>n;
    point p[n];
    for(int i=0;i<n;i++)
    cin>>p[i].x>>p[i].y;
     cout<<bruteforce(p,0,n-1)<<endl;
    sort(p,n);
    double ans=closestpoint(p,0,n-1);
    cout<<ans<<endl;
}
/*6
2 3
5 1
12 30
40 50
12 10
3 4*/