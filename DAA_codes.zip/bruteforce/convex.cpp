#include<bits/stdc++.h>
using namespace std;
class point{
    public:
    int x,y;
};
int main()
{
    int n;
    cin>>n;
    point p[n];
    for(int i=0;i<n;i++)
    {
        cin>>p[i].x>>p[i].y;
    }
    for(int i=0;i<n-1;i++)
    {
        for(int j=i+1;j<n;j++)
        {
            int a=p[j].y-p[i].y;//y2-y1
            int b=p[i].x-p[j].x;//x1-x2
            int c=(p[i].y *p[j].x)-(p[j].y*p[i].x);//y1x2-y2x1
            int neg=0,pos=0;
            for(int k=0;k<n;k++)
            {
                int d=a*p[k].x+b*p[k].y+c;//ax+by+c
                if(d<0)
                neg++;
                if(d>0)
                pos++;

            }
            if(pos==0 || neg==0)
            cout<<"("<<p[i].x<<","<<p[i].y<<")"<<" " <<"("<<p[j].x<<","<<p[j].y<<")"<<endl;
        }
    }
}
/*
7 
1 2
2 3
2 4
3 2
4 1
5 3
4 4
(1,2) (2,4)
(1,2) (4,1)
(2,4) (4,4)
(4,1) (5,3)
(5,3) (4,4)*/