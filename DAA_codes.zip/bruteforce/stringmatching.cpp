#include<bits/stdc++.h>
using namespace std;
int main()
{
    
    string text,pat;
    cin>>text>>pat;
    int n=text.size();
    int m=pat.size();
    if(n<m)
    return -1;
    for(int i=0;i<n-m;i++)
    {
        int f=0;
        for(int j=0;j<m;j++)
        {
            if(text[i+j]!=pat[j])
            f=1;

        }
        if(f!=1)
        {
            cout<<"pattern is found at "<<i<<endl;
            break;
        }
    }

}