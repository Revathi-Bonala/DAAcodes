#include<bits/stdc++.h>
using namespace std;
int recc(int n,int r)
{
    if(n<r) return -1;
    if(r==0 || r==n) return 1;
    if(r==1)  return n;
    
    return recc(n-1,r-1)+recc(n-1,r);
}
int memo(int n,int r,vector<vector<int>>& dp)
{
      if(n<r) return -1;
    if(r==0 || r==n) return 1;
    if(r==1)  return n;
    if(dp[n][r]!=-1) return dp[n][r];
    
    return dp[n][r]=memo(n-1,r-1,dp)+memo(n-1,r,dp);

}
int table(int n,int r,vector<vector<int>>& tb)
{
    for(int i=0;i<=n;i++)
    {
        for(int j=0;j<=r;j++)
        {
            if(j>i) tb[i][j]=0;
            else if(j==0 || j==i)
            tb[i][j]=1;
            else if(j==1) tb[i][j]=i;
            else 
            tb[i][j]=tb[i-1][j-1]+tb[i-1][j];
        }
    }
    return tb[n][r];
}
int main()
{
    int n,r;
    cin>>n>>r;
    int k=recc(n,r);
    cout<<k<<endl;
    vector<vector<int>>dp(n+1,vector<int>(r+1,-1));
    cout<<memo(n,r,dp)<<endl;
    vector<vector<int>>tb(n+1,vector<int>(r+1,0));
    cout<<table(n,r,tb)<<endl;
    for(int i=0;i<=n;i++)
    {
        for(int j=0;j<=r;j++)
        cout<<tb[i][j]<<" ";
        cout<<"\n";
    }
}