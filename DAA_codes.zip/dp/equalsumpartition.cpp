#include<bits/stdc++.h>
using namespace std;
      int func(int a[],int n,int sum)
      {
          if(sum==0)
          return 1;
          if(n==0)
          return 0;
          if(a[n-1]>sum)
          return func(a,n-1,sum);
          else
          return func(a,n-1,sum-a[n-1])||func(a,n-1,sum);
      }
      int memo(int a[],int n,int sum,vector<vector<int>>& dp)
      {
          if(sum==0) return 1;
          if(n==0 ) return 0;
          if(dp[n][sum]!=-1)
          return dp[n][sum];
          if(a[n-1]<=sum)
          return dp[n][sum]=memo(a,n-1,sum-a[n-1],dp)||memo(a,n-1,sum,dp);
          else
          return dp[n][sum]=memo(a,n-1,sum,dp);
      }
      int table(int a[],int n,int sum,vector<vector<int>>& dp)
      {
          int i,j;
          for( i=0;i<=n;i++)
          {
              for( j=0;j<=sum;j++)
              {
                  if(j==0)
                  dp[i][j]=1;
                  else if(i==0)
                  dp[i][j]=0;
                  else if(a[i-1]<=j)
                  dp[i][j]=dp[i-1][j-a[i-1]]||dp[i-1][j];
                  else
                  dp[i][j]=dp[i-1][j];
              }
          }
          return dp[n][sum];
      }
    int equalPartition(int n, int arr[])
    {
        // code here

        int sum=0;
        for(int i=0;i<n;i++) sum+=arr[i];
        if(sum%2) 
        return false;
                vector<vector<int>>dp(n+1,vector<int>(sum+1,0));
        
            sum=sum/2;
            return table(arr,n,sum,dp);
            // return func(arr,n,sum)
    }

int main()
{
    int n;
    cin>>n;
    int a[n];
    for(int i=0;i<n;i++)
    {
        cin>>a[i];
    }
   cout<<equalPartition(n,a);
}