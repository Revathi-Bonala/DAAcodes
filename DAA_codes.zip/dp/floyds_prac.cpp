#include<bits/stdc++.h>
using namespace std;
void floyds(vector<vector<int>>& adj,int n,int e)
{
    for(int via=0;via<n;via++)
    {
       for(int i=0;i<n;i++)
       {
        for(int j=0;j<n;j++)
        {
            if(i==j) adj[i][j]=0;
            else 
            adj[i][j]=min(adj[i][j],adj[i][via]+adj[via][j]);
        }
       }
    }       
}
int main()
{
    int n,edges;
    cin>>n>>edges;
    vector<vector<int>>adj(n+1,vector<int>(n+1,1e9));
    for(int i=0;i<edges;i++)
    {
        int u,v,w;
        cin>>u>>v>>w;
        adj[u][v]=w;
    }
    floyds(adj,n,edges);
    for(int i=0;i<n;i++)
    {
        for(int j=0;j<n;j++)
        {
            if(adj[i][j]==1e9)
            cout<<-1<<" ";
            else
        cout<<adj[i][j]<<" ";
        }
        cout<<"\n";
    }
}