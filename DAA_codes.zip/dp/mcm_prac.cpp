#include<bits/stdc++.h>
using namespace std;
int recc(int m[],int i,int j)
{
    
    if(i==j)
    return 0;
    int mini=INT_MAX;
    for(int k=i;k<j;k++)
    {
        int val=recc(m,i,k)+recc(m,k+1,j)+m[i-1]*m[j]*m[k];
        mini=min(mini,val);

    }
    return mini;
}
int memo(int m[],int i,int j,vector<vector<int>>& dp)
{
    
    if(i==j)
    return 0;
    int mini=INT_MAX;
    if(dp[i][j]!=-1)
    return dp[i][j];
    for(int k=i;k<j;k++)
    {
        int val=memo(m,i,k,dp)+memo(m,k+1,j,dp)+m[i-1]*m[j]*m[k];
        mini=min(mini,val);

    }
    return dp[i][j]=mini;
}
int table(int m[],int n,vector<vector<int>>& dp)
{
    int j;
    for(int x=0;x<n;x++)
    {
        for(int i=0;i<=n-x;i++)
        {
            j=i+x;
            if(i==j) dp[i][j]=0;
            else
            {
                int mini=INT_MAX;
                for(int k=i;k<j;k++)
                {
                    int val=dp[i][k]+dp[k+1][j]+m[i-1]*m[j]*m[k];
                    mini=min(mini,val);
                }
                dp[i][j]=mini;
            }
        
        }

    }
    return dp[1][n-1];
}
int main()
{
    int n;
    cin>>n;
    int m[n];
    for(int i=0;i<n;i++) cin>>m[i];
    cout<<recc(m,1,n-1)<<endl;
    vector<vector<int>>dp(n+1,vector<int>(n+1,0));
    cout<<table(m,n,dp)<<endl;
    for(int i=0;i<n;i++)
    {
        for(int j=0;j<n;j++)
        {
            if(i==0)
            cout<<0<<" ";
            else
        cout<<dp[i][j]<<" ";
        }
        cout<<"\n";
    }

}