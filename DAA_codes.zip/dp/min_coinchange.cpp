#include<bits/stdc++.h>
using namespace std;
int recc(int cost[],int n,int sum)
{
    if(sum==0) return 0;
    if(n==0) return 1e9;
    if(cost[n-1]<=sum)
    return min(1+recc(cost,n,sum-cost[n-1]),recc(cost,n-1,sum));
    return recc(cost,n-1,sum);
}
int memo(int cost[],int n,int sum,vector<vector<int>>& dp)
{
    if(sum==0) return 0;
    if(n==0) return 1e9;
    if(dp[n][sum]!=-1) return dp[n][sum];
    if(cost[n-1]<=sum)
    return dp[n][sum]=min(1+memo(cost,n,sum-cost[n-1],dp),memo(cost,n-1,sum,dp));
    return dp[n][sum]=memo(cost,n-1,sum,dp);
}
int t(int cost[],int n,int sum,vector<vector<int>>& dp)
{
    for(int i=0;i<=n;i++)
    {
        for(int j=0;j<=sum;j++)
        {
            if(j==0) dp[i][j]=0;
            else if(i==0) dp[i][j]=1e9;
            else if(cost[i-1]<=j)
            dp[i][j]=min(1+dp[i][j-cost[i-1]],dp[i-1][j]);
            else
            dp[i][j]=dp[i-1][j];
        }
    }
    return dp[n][sum];
}
int main()
{
    int n,sum;
    cin>>n>>sum;
    int cost[n];
    for(int i=0;i<n;i++)
    cin>>cost[i];
    cout<<recc(cost,n,sum)<<endl;
    vector<vector<int>>dp(n+1,vector<int>(sum+1,0));
    cout<<t(cost,n,sum,dp)<<endl;
    for(int i=0;i<=n;i++)
    {
        for(int j=0;j<=sum;j++)
        {
            cout<<dp[i][j]<<" ";
        }
        cout<<"\n";

    }
}