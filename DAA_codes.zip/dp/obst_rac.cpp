#include<bits/stdc++.h>
using namespace std;
int frequency(int f[],int i,int j)
{
    int fsum=0;
    for(int l=i;l<=j;l++)
    fsum+=f[l];
    return fsum;
}
int recc(int freq[],int i,int j)
{
    if(i>j) return 0;
    if(i==j) return freq[i];
    int mini=INT_MAX;
    for(int k=i;k<=j;k++)
    {
        int val=recc(freq,i,k-1)+recc(freq,k+1,j);
        mini=min(val,mini);
        
    }
    return mini+frequency(freq,i,j);
}
int memo(int freq[],int i,int j,vector<vector<int>>& dp)
{
    if(i>j) return 0;
    if(i==j) return freq[i];
    int mini=INT_MAX;
    for(int k=i;k<=j;k++)
    {
        int val=recc(freq,i,k-1)+recc(freq,k+1,j);
        mini=min(val,mini);
        
    }
    return dp[i][j]=mini+frequency(freq,i,j);
}
int table(int freq[],int n,vector<vector<int>>& dp)
{
     for(int x=0;x<n;x++)
     {
        for(int i=1;i<=n-x;i++)
        {
            int j=i+x;
            if(i==j) dp[i][j]=freq[i];
            else{
                int mini=INT_MAX;
                for(int k=i;k<=j;k++)
                {
                    int val=((k-1<i)?0:dp[i][k-1])+((k+1>j)?0:dp[k+1][j]);
                    mini=min(mini,val);
                }
                dp[i][j]=mini+frequency(freq,i,j);

            }
        }
     }
     return dp[1][n];
}

int main()
{
    int n;
    cin>>n;
    int freq[n+1];
    freq[0]=0;
    for(int i=1;i<=n;i++) cin>>freq[i];
   cout<<recc(freq,1,n)<<endl;
   vector<vector<int>>dp(n+1,vector<int>(n+1,-1));
   cout<<memo(freq,1,n,dp)<<endl;
//    cout<<table(freq,n,dp)<<endl;
   for(int i=0;i<=n;i++)
   {
    for(int j=0;j<=n;j++)
    {
        cout<<dp[i][j]<<" ";

    }
    cout<<"\n";
   }
}