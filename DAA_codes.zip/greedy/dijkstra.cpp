#include<bits/stdc++.h>
using namespace std;
void dijkstras(vector<pair<int,int>> adj[],int n,vector<int>& dist,int src)
{
   priority_queue<pair<int,int>,vector<pair<int,int>>,greater<pair<int,int>>>pq;
   pq.push({0,src});
   dist[src]=0;
   while(!pq.empty())
   {
    auto node=pq.top();
    pq.pop();
    int d=node.first;
    int n=node.second;
    for(auto it:adj[n])
    {
        int k=it.first;
        if(k+d<dist[it.second] )
        {
            dist[it.second]=k+d;
            pq.push({k+d,it.second});
        }
    }
   }
}
int main()
{
    int n,e;
    cin>>n>>e;
    vector<pair<int,int>>adj[n+1];
    for(int i=0;i<e;i++)
    {
        int u,v,w;
        cin>>u>>v>>w;
        adj[u].push_back({w,v});
        adj[v].push_back({w,u});
    }
    vector<int>dist(n+1,1e9);
    dijkstras(adj,n,dist,1);
    for(int i=1;i<=n;i++) 
    cout<<dist[i]<<" ";
}