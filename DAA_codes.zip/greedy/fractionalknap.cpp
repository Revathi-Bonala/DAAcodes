#include<bits/stdc++.h>
using namespace std;
void swap(int j,int k,int a[])
{
    int temp=a[j];
    a[j]=a[k];
    a[k]=temp;
}
int main()
{
    int n,w;
    cin>>n>>w;
    int wt[n],val[n];
    for(int i=0;i<n;i++) cin>>wt[i];
    for(int i=0;i<n;i++) cin>>val[i];
    for(int i=0;i<n;i++)
    {
        for(int j=0;j<n-i-1;j++)

        {
            if((val[j]/wt[j] )<(val[j+1]/wt[j+1]))
            {
                swap(j,j+1,wt);
                swap(j,j+1,val);
            }
        }
    }
    for(int i=0;i<n;i++) cout<<wt[i]<<" ";
    cout<<endl;
    for(int i=0;i<n;i++) cout<<val[i]<<" ";
    cout<<endl;
    int sum=0;
   for(int i=0;i<n;i++)
   {
    if(wt[i]<=w)
    {
        sum+=val[i];
        w-=wt[i];
    }
    else
    {
        sum+=(val[i]/wt[i])*w;
        w=0;
    }
   }
   cout<<sum<<endl;
}