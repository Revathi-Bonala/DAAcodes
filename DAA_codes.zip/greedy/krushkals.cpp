#include<bits/stdc++.h>
using namespace std;
class disjointset{
    vector<int>size,parent;
    public:
    disjointset(int n)
    {
        size.resize(n+1);
        parent.resize(n+1);
        for(int i=0;i<n;i++)
        {
            size[i]=1;
            parent[i]=i;
        }
    }
    int findul_p(int node)
    {
       if(node==parent[node]) return node;
       return parent[node]=findul_p(parent[node]);

    }
    
    void union_bysize(int u,int v)
    {
        int ulp_u=findul_p(u);
        int ulp_v=findul_p(v);
        if(ulp_u==ulp_v) return;
        if(size[ulp_u]<size[ulp_v])
        {
            parent[ulp_u]=ulp_v;
            size[ulp_v]+=size[ulp_u];
        }
        else if(size[ulp_v]<size[ulp_u])
        {
            parent[ulp_v]=ulp_u;
            size[ulp_u]+=size[ulp_v];
        }
        else
        {
            parent[ulp_v]=ulp_u;
            size[ulp_u]+=size[ulp_v];
        }
           }
};
int krushkals(int n,int e)
{
    int w=0;
    vector<pair<int,pair<int,int>>>edgewt;
    for(int i=0;i<e;i++)
    {
        int u,v,w;
        cin>>u>>v>>w;
        edgewt.push_back({w,{u,v}});
    }
    sort(edgewt.begin(),edgewt.end());
    disjointset ds(n);
    for(auto it:edgewt)
    {
        int wt=it.first;
        int u=it.second.first;
        int v=it.second.second;
        if(ds.findul_p(u)!=ds.findul_p(v))
        {
            w+=wt;
            ds.union_bysize(u,v);
        }
       

    }
     return w;
}
int main()
{
    int n,e;
    cin>>n>>e;
    int k=krushkals(n,e);
    cout<<k<<endl;
}

/*
6
0 1 2
2 3 4
4 5 9
2 5 7
1 4 5


*/