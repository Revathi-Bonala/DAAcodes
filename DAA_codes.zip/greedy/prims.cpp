#include<bits/stdc++.h>
using namespace std;
void prims(vector<vector<int>>& adj,int n)
{
    vector<int>vis(n+1,0);
    int it=1,src,dest;
    vis[0]=1;
    while(it<n)
    {
        int mini=INT_MAX;
          for(int i=0;i<n;i++)
          {
            if(vis[i]==1)
            {
                
                for(int j=0;j<n;j++)
                {
                    if(vis[j]==0 && adj[i][j]!=0)
                    {
                        if(adj[i][j]<mini)
                        {
                            mini=adj[i][j];
                         src=i;
                         dest=j;
                        }
                    }
                }
            }
          }
          it++;
          vis[dest]=1;
          cout<<src <<"to"<<" "<<dest<<" is "<<adj[src][dest]<<endl;
    }
}
int main()
{
    int n,e;
    cin>>n>>e;
    vector<vector<int>>adj(n+1,vector<int>(n+1,0));
    for(int i=0;i<e;i++)
    {
        int u,v,w;
        cin>>u>>v>>w;
        adj[u][v]=w;
        adj[v][u]=w;
    }
    prims(adj,n);
}
/* 6
8
0 1 2
1 2 6
2 3 4
4 5 9
5 0 3
2 5 7
3 4 8
1 4 5
0to 1 is 2
0to 5 is 3
1to 4 is 5
1to 2 is 6
2to 3 is 4*/