#include<bits/stdc++.h>
using namespace std;
int mergesort(int a[],int lb,int mid,int ub)
{
    int l=mid-lb+1;
    int r=ub-mid;
    int L[l],R[r];
    for(int i=0;i<l;i++)
    {
        L[i]=a[lb+i];
    }
     for(int i=0;i<r;i++)
    {
        R[i]=a[mid+i+1];
    }
    int i=0,j=0,k=lb;
    while(i<l && j<r)
    {
      if(L[i]<=R[j])
      {
        a[k]=L[i];
        i++;
      }
      else
      {
        a[k]=R[j];
        j++;
      }
      k++;

    }
    while(i<l)
    {
        a[k]=L[i];
        i++;
        k++;
    }
    while(j<r)
    {
        a[k]=R[j];
        j++;  
        k++;
    }

}


void merge(int a[],int lb,int ub)
{
    if(lb<ub)
    {
        int mid=(lb+ub)/2;
        merge(a,lb,mid);
        merge(a,mid+1,ub);
        mergesort(a,lb,mid,ub);
    }
}
int main()
{
    int n;
    cin>>n;
    int a[n];
    for(int i=0;i<n;i++)
    {
        cin>>a[i];

    }
   merge(a,0,n-1);
    for(int i=0;i<n;i++)
    cout<<a[i]<<" ";
}